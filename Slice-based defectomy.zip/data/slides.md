# Slice-based Defectomy

Removal of failures using dependency chain

(_a.k.a. debugging_)

--

# Who am I 

![me](https://spoorcc.github.io/images/bio-photo.png)

[ben.spoor.cc](www.spoor.cc)

---

# Contents


## Why?
<!-- .element: class="fragment" -->

## What?
<!-- .element: class="fragment" -->

## How?
<!-- .element: class="fragment" -->

---

# Why defectomy?

--

## Daily activity

1. Write test
<!-- .element: class="fragment" -->

2. Write some code
<!-- .element: class="fragment" -->

3. Run test ~ fails
<!-- .element: class="fragment" -->

4. __What failed?__
<!-- .element: class="fragment" -->

5. __Fix failure__
<!-- .element: class="fragment" -->

--

## Research shows

- ~50% of your time spent solving bugs
- $312 billion spent annually (2012)

--

![image](http://d2lupdnmi5p5au.cloudfront.net/i__src9db33f136729319776dcb448021ef7d1_paraf0d99c20bd457d46a92c72841873c47.jpeg)

-- 

## Education 

- Design / Architecture
- Tools / techniques
- Writing software
- ~~Debugging~~ 

---

# What is slice-based defectomy?

--

## Structured process to find and correct defects

---

# How can I do this?

--

1. Understand
2. Find
3. Fix

---

## Step 1. Understand

Goal: Understand needle & haystack

--

## Step 1. Understand

1. Understand
   1. _Check the obvious_
   2. _Describe the problem_
   3. _Reproduce the failure_
2. Find
3. Fix

--

### Check the obvious

* Am I doing what I expect?
* Is it plugged in?

--

### Describe the problem

* What did I expect to happen?
* What did happen?

--

### Reproduce the failure

What steps are needed to reproduce the failure?

--

## Understand

__Given__ I have A, <br>
__When__ I do B,<br>
__Then__ I should see C,<br>
__But__ I see D

---

1. ~~Understand~~
2. __Find__
3. Fix

--

## Step 2. Find

Goal: Find needle in haystack

--

## Step 2. Find

1. Understand
2. Find
    1. _Simplify_
    2. _Isolate_
    3. _Pinpoint_
3. Fix


--

### Simplify

Remove any steps/items not neccesary for reproduction

--

### Isolate

What is unique to unwanted situation?

--

### Isolate

* Inputs
* Transformations
* Outputs

--

### Pinpoint defect

* Identify cause-effect chain
* Methodicaly follow it to defect

--

## Find

Location of defect with description of how

---

1. ~~Understand~~
2. ~~Find~~
3. __Fix__

--

## Step 3. Fix

Goal: Remove needle from haystack

--

## Step 3. Fix

1. Understand
2. Find
3. Fix
    1. Apply
    2. Test
    3. Look around

--

### Apply

* Given defect apply fix to code
* Reproduction impossible

--

### Test

Test other values/uses

--

### Look around

Check similar code, defects cluster

--

## Fix

Defect is removed, software is improved &#10003;

